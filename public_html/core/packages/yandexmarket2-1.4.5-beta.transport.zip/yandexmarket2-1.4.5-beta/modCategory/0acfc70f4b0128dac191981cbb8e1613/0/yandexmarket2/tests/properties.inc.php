<?php

/* define some properties */
$properties['runtime'] = date('Ymd\THis');
$properties['config_key'] = 'config';

/* driver-specific connection properties */
/* mysql */
$properties['mysql_string_dsn_test'] = 'mysql:host=127.0.0.1;dbname='.getenv('MYSQL_DATABASE').';charset=utf8';
$properties['mysql_string_dsn_nodb'] = 'mysql:host=127.0.0.1;charset=utf8';
$properties['mysql_string_dsn_error'] = 'mysql:host= nonesuchhost;dbname=nonesuchdb';
$properties['mysql_string_username'] = getenv('MYSQL_USERNAME');
$properties['mysql_string_password'] = getenv('MYSQL_PASSWORD');
$properties['mysql_array_options'] = [
    xPDO::OPT_HYDRATE_FIELDS => true,
    xPDO::OPT_HYDRATE_RELATED_OBJECTS => true,
    xPDO::OPT_HYDRATE_ADHOC_FIELDS => true,
];
$properties['mysql_array_driverOptions'] = [\PDO::ATTR_ERRMODE => \PDO::ERRMODE_SILENT];

$properties['xpdo_driver'] = 'mysql';
$properties['logTarget'] = [
    'target' => 'file',
    'options' => [
        'filename' => "unit_test_{$properties['runtime']}.log",
        'filepath' => __DIR__. '/'
    ]
];
$properties['logLevel'] = xPDO::LOG_LEVEL_INFO;
$properties['context'] = 'web';
$properties['debug'] = false;
