cityConfig = {
	token: ""
  	,key: ""

};
					